import React from 'react';

const About = () =>
    <div>
        Just a dummy page to showcase react-router!
    </div>;


export default About;
